# evga Preferences

- rule: do the work in Claude's sandbox ("your pc"), not by asking the user to run things on their own PC
- never delete files from a project without saying so — list every deletion and restore what was removed unannounced
- report multi-part status as a numbered item list, not prose — they reply by item number
- never do anything without asking first — always confirm before taking action
- ALWAYS save 4 exports on "export": (1) session journal, (2) memory backup as individual files in correct directories, (3) transcript, (4) preferences. Zip: <handle>-memory-backup-<date>.zip
