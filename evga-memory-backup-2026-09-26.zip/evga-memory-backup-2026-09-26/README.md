# evga Memory Backup — 2026-09-26

Memory files exported from Claude's memory system.
These files are the source of truth for project context across sessions.

## Files
- profile.md — crew profile
- areas/ — active project files
- people/ — people context
- topics/ — topical notes
- preferences.md — stored preferences
- session-journal.md — this session's work
