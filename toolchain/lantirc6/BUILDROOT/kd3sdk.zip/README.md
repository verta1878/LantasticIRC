# Knowledge Dynamics wINSTALL SDK V3.22
## Customized by Artisoft, Inc. (1994)

### Overview
Knowledge Dynamics Corp. provided the INSTALL.EXE framework used by
approximately 7,000 software companies including Borland, Lotus, 
Harvard Graphics, Autodesk, and Artisoft.

Artisoft licensed wINSTALL V3.22 and customized it as "Artisoft Install"
for LANtastic v6.x distribution.

### Authors (from binary strings)
- Eric Jon Heflin
- Larry Hastings  
- Darryl Rust

### Technical Details
- **Framework**: Knowledge Dynamics wINSTALL V3.22
- **Copyright**: (c) 1993 Knowledge Dynamics Corp. All rights reserved.
- **Customization**: (c) 1994 Artisoft, Inc.
- **Compiler**: Microsoft C 6.0 or 7.0
- **Architecture**: DOS MZ executable with 32 overlay segments
- **Overlay Manager**: Knowledge Dynamics custom (not Microsoft OVLMGR)
- **Base EXE**: 120KB (entry stub + overlay loader)
- **Overlays**: 316KB (actual program code, 32 segments)
- **Total**: 436KB (INST6.EXE)

### Compression Algorithm
- **Type**: LZW with dictionary reset
- **Bit width**: Variable, 9-12 bits
- **Dictionary**: Reset on CLEAR code (256)
- **EOF**: Code 257
- **First user code**: 258
- **Reference**: ModdingWiki "Knowledge Dynamics LZW COMPRESSOR"
- **Open-source decompressor**: openkb project (unexecomp.c, public domain)
  https://sourceforge.net/p/openkb/code/ci/master/tree/src/tools/unexecomp.c

### NOS Archive Format
The installer uses NOS.001-004 archive files containing compressed files:
- **Magic**: "RR\x01" (2 bytes 'R','R' + version byte 0x01)
- **Record header**: 20 bytes before each filename
  - Bytes 0-1: 0x1C61 (marker)
  - Bytes 2-3: compressed size (16-bit LE)
  - Bytes 6-7: uncompressed size low word (16-bit LE)
  - Bytes 18-19: filename length
- **Filename**: 8.3 format, null-terminated
- **Data**: LZW compressed block

### Install Script Language
INSTALL.DAT is a text script with commands:
- @DECOMPRESS — extract and decompress file from NOS archive
- @COLORRES, @STRRFIND — UI commands
- @MkDir — create directory
- @Immediate — immediate mode operations

### Source Files (from string references in binary)
- main.c — main program / command dispatcher
- s_openin.c — archive open/read/decompress
- expand.c — file expansion (decompression wrapper)

### Key Strings in Binary
- "Decompressing: %s"
- "Unable to read compressed file header"
- "Corrupted library file header"
- "Unknown compression technique"
- "Decompression error: %d"
- "Can't write output data during decompression phase"
- "Library file has a length of 0"
- "File expected but not found in library"
- "Corrupted library file - Unknown record type %d"
- "Fatal Artisoft Install Error"

### Ghidra Decompilation
INST6.EXE decompiled to 717 functions, 49,772 lines of C.
Located in: analysis/INST6/INST6_decompiled.c

### References
- Microsoft KB Q77471: Knowledge Dynamics INSTALL.EXE and MS-DOS 5.0
- ModdingWiki: Knowledge Dynamics LZW COMPRESSOR
- openkb project: unexecomp.c decompressor (SourceForge)
- ReWolf's blog: Reverse engineering Might and Magic III compression
