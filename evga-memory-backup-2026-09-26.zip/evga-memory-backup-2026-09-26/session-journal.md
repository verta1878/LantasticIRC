# evga Session Journal — 2026-09-26
## LANtastic v6.0 DOS NOS Recovery (LantasticIRC)

### Session Work
1. Created full project zip with cleanup.bat for GitHub push
2. Compared zip vs repo — identified 53 files in repo not in zip (BUILDROOT/KD3SDK/WDKSDK)
3. Gave safe commit instructions (selective git add, NOT git add -A)
4. GitHub Desktop instructions for non-git-CLI workflow
5. A7: NOS archive tool (nosextract.py) — 239 files, 186/239 verified, proprietary compression not yet reversed
6. A8: Binary classification — 66 executables (43 DOS MZ, 14 Win NE, 1 OS/2 NE, 8 COM); no FBOV overlays; 28 hand-ASM self-relocating, 3 BC3.1, 2 MSC
7. Installed Python 3.13, rebrew 2.6.0 — ran intake on INITCTL.EXE (71 functions, borland-3.1 toolchain)
8. TC3.0 FLIRT sigs: 535 loaded, 0 exact matches (BC3.1 CRT differs slightly)
9. INITCTL code map: _main at 0x02C2, 27% user code, 73% CRT
10. Built Rizin 0.10.0 from source + objconv from Agner Fog
11. NE3.EXE: 86 functions in 8KB via CALL target analysis
12. Created flat 84-item TODO (126 binaries byte-exact scope)
13. Updated PHASE_ROADMAP.md with full scope

### Key Findings
- Code page 0 → 437 fallback = root cause of mount invisibility under Wine
- SDL_VIDEODRIVER=dummy = headless Wine without Xvfb
- REDIR blocking file I/O = proof the stack is functional
- Core DOS stack = hand-written ASM (no compiler strings)
- NOS archive format: magic "RR\x01", 41-byte header, proprietary Knowledge Dynamics compression
- 28 self-relocating binaries use PSP[0x0C] trick (0 relocations)

### Artifacts Created
- docs/BINARY_CLASSIFICATION.md
- docs/INITCTL_ANALYSIS.md
- docs/TOOLS.md
- toolchain/nosextract.py
- decompile/initctl/ (rebrew project)
- cleanup.bat

### SHA256
Latest zip: a03d07659f8b7b60b46a363b3b221af03e825c618c6135b1ecdbfe3daee09cd3
